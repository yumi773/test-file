document.addEventListener('DOMContentLoaded', () => {
  const refreshBtn = document.getElementById('refreshBtn');

  // 初始化：讀取儲存的舊資料
  chrome.storage.local.get(['readmoo_data'], (result) => {
    if (result.readmoo_data) renderBooks(result.readmoo_data);
  });

  refreshBtn.addEventListener('click', async () => {
    refreshBtn.innerText = '抓取中...';
    refreshBtn.disabled = true;

    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: "DO_SCRAPE" }, () => {
          setTimeout(() => {
            refreshBtn.innerText = '⟳ 刷新資料';
            refreshBtn.disabled = false;
          }, 600);
        });
      }
    } catch (err) {
      alert("請確保您在讀墨購物車或待購清單頁面！");
      refreshBtn.disabled = false;
    }
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.readmoo_data) {
      renderBooks(changes.readmoo_data.newValue);
    }
  });
});

// ... 前方 DOMContentLoaded 與按鈕監聽邏輯維持 2.1 版本不變 ...

function renderBooks(books) {
  const app = document.getElementById('app');
  const saleBooks = books.filter(b => b.isSale);

  if (saleBooks.length === 0) {
    app.innerHTML = '<div style="padding:20px; color:#999; text-align:center;">目前無活動書籍。</div>';
    return;
  }

  // 1. 先定義置頂的統計列
  const headerHtml = `
    <div class="sticky-header">
      🔍 偵測到 ${saleBooks.length} 本參與活動/特價書籍：
    </div>
  `;

  // 2. 再定義書籍清單內容
  const listHtml = saleBooks.map(b => `
    <div class="book-item">
      <div style="margin-bottom: 5px;">
        <a href="${b.url}" target="_blank" style="text-decoration: none; color: #333; font-weight: bold; font-size: 14px;">
          ${b.title} 
        </a>
      </div>
      
      <div class="price-row">
        <span style="color: ${b.hasPriceTag ? '#FF5252' : '#333'};">NT$ ${b.price}</span>
        ${b.hasPriceTag ? `
          <span style="background: #7e7676; color: white; font-size: 10px; padding: 2px 6px; border-radius: 10px; margin-left: 8px; vertical-align: middle;">
            🔥 特價中
          </span>
        ` : ''}
      </div>
      
      ${b.activities.map(act => `
        <a href="${act.link}" target="_blank" class="activity-link">
          📍 ${act.text} <span style="float:right;">➜</span>
        </a>
      `).join('')}
    </div>
  `).join('');

  // 3. 組合起來放入 app
  app.innerHTML = headerHtml + listHtml;
}