document.addEventListener('DOMContentLoaded', renderCache);

async function renderCache() {
    const results = document.getElementById('results');
    const lastScanTime = document.getElementById('lastScanTime');
    const expirySummary = document.getElementById('expirySummary');
    const data = await chrome.storage.local.get(['readmooCache']);
    
    results.innerHTML = '';
    expirySummary.innerText = '';
    
    if (data.readmooCache && data.readmooCache.length > 0) {
        const todayStr = new Date().toISOString().split('T')[0].replace(/-/g, '/');
        
        // 1. 過濾掉確定已過期的書籍
        const validData = data.readmooCache.filter(b => {
            if (b.expiryDate === "詳見網頁") return true; // 無法判斷日期的先保留
            return b.expiryDate >= todayStr;
        });
        
        lastScanTime.innerText = `最後掃描：${new Date(data.readmooCache[0].timestamp).toLocaleString()}`;
        
        if (validData.length > 0) {
            expirySummary.innerText = `⚠️ 偵測到 ${validData.length} 本書版權即將到期`;
            
            // 2. 強化排序邏輯：解決日期錯置問題
            validData.sort((a, b) => {
                // 如果是「詳見網頁」，設定一個很大的日期讓它排在最後
                const dateA = a.expiryDate === "詳見網頁" ? "9999/12/31" : a.expiryDate;
                const dateB = b.expiryDate === "詳見網頁" ? "9999/12/31" : b.expiryDate;
                
                // 直接比較字串 YYYY/MM/DD，這在 JavaScript 中是最穩定的日期排序方式
                if (dateA < dateB) return -1;
                if (dateA > dateB) return 1;
                return 0;
            });

            validData.forEach(book => displayBook(book));
        } else {
            expirySummary.innerText = '目前無即將過期書籍';
        }
    } else {
        lastScanTime.innerText = '目前無快取，請執行掃描。';
    }
}

function displayBook(book) {
    const results = document.getElementById('results');
    const div = document.createElement('div');
    div.className = 'book-item';
    div.innerHTML = `
        <div style="font-size: 14px;">
            <a href="${book.url}" target="_blank" style="text-decoration: none; color: #4a4443; font-weight: bold;">
                ${book.title}
            </a>
        </div>
        <div style="margin-top: 5px; font-size: 13px; color: #917c79; font-weight: bold;">⏱︎ 到期日: ${book.expiryDate}</div>
    `;
    results.appendChild(div);
}

document.getElementById('scanBtn').addEventListener('click', async () => {
    const lastScanTime = document.getElementById('lastScanTime');
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab.url.includes("readmoo.com/checkout")) {
        lastScanTime.innerHTML = `<span style="color:red">請在購物車或待購清單頁面執行</span>`;
        return;
    }

    const data = await chrome.storage.local.get(['readmooCache']);
    let expiryBooks = data.readmooCache || [];

    await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => { localStorage.removeItem('rm-silent-mode'); }
    });

    try {
        const injection = await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
                const links = Array.from(document.querySelectorAll('a[href*="/book/"]')).map(a => a.href).filter(url => url.startsWith('http'));
                return [...new Set(links)];
            }
        });

        const urls = injection[0].result;

        for (let [index, url] of urls.entries()) {
            if (expiryBooks.some(b => b.url === url)) continue;
            lastScanTime.innerText = `正在掃描: ${index + 1} / ${urls.length}`;
            try {
                const resp = await fetch(url);
                const text = await resp.text();
                if (text.includes("版權即將到期")) {
                    const parser = new DOMParser();
                    const doc = parser.parseFromString(text, 'text/html');
                    const title = doc.querySelector('h1')?.innerText?.trim() || "未知書籍";
                    const expiry = text.match(/版權即將到期：\s*(\d{4}\/\d{2}\/\d{2})/)?.[1] || "詳見網頁";
                    expiryBooks.push({ title, url, expiryDate: expiry, timestamp: Date.now() });
                    await chrome.storage.local.set({ readmooCache: expiryBooks });
                }
            } catch (e) { console.error(e); }
        }
        renderCache();
    } catch (err) { lastScanTime.innerText = '出錯：' + err.message; }
});

document.getElementById('clearBtn').addEventListener('click', async () => {
    await chrome.storage.local.remove('readmooCache');
    renderCache();
});