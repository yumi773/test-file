function triggerModal(cache) {
    const today = new Date();
    today.setHours(0, 0, 0, 0); // 正規化今日時間

    const validBooks = cache.filter(b => {
        const expiry = new Date(b.expiryDate);
        return b.expiryDate === "詳見網頁" || expiry >= today;
    });

    // 執行排序：日期近（快到期）-> 遠，詳見網頁排最後
    validBooks.sort((a, b) => {
        const dateA = a.expiryDate === "詳見網頁" ? "9999/12/31" : a.expiryDate;
        const dateB = b.expiryDate === "詳見網頁" ? "9999/12/31" : b.expiryDate;
        return dateA.localeCompare(dateB);
    });

    // 檢查是否應顯示彈窗
    if (validBooks.length === 0 || 
        localStorage.getItem('rm-silent-mode') === 'true' || 
        sessionStorage.getItem('hasAlertedExpiry') || 
        document.getElementById('rm-custom-modal')) return;

    const modalOverlay = document.createElement('div');
    modalOverlay.id = 'rm-custom-modal';
    modalOverlay.style.cssText = "position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.7); z-index:100000; display:flex; align-items:center; justify-content:center; font-family:'Microsoft JhengHei', sans-serif;";

    let booksHtml = validBooks.map(b => {
        // 計算剩餘天數
        const expiryDate = new Date(b.expiryDate);
        const diffTime = expiryDate - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        
        let dayText = diffDays > 0 ? `剩 ${diffDays} 天` : (diffDays === 0 ? "今天到期" : "未知");
        
        return `
            <div style="background:#d6c9c7; margin-bottom:13px; padding:12px 15px; border-radius:10px; text-align:left; box-shadow:0 2px 6px rgba(0,0,0,0.05);">
                <div style="display:flex; justify-content:space-between; align-items:center; gap:15px;">
                    <a href="${b.url}" target="_blank" style="font-weight:bold; font-size:14px; color:#4a4443; text-decoration:none; border-bottom:1px solid #917c79; flex:1; line-height:1.4;">
                        📌 ${b.title}
                    </a>
                    <span style="background:#917c79; color:#f8f7f2; padding:4px 10px; border-radius:6px; font-size:13px; font-weight:bold; white-space:nowrap; min-width:65px; text-align:center;">
                        ${dayText}
                    </span>
                </div>
            </div>
        `;
    }).join('');

    modalOverlay.innerHTML = `
        <div style="background:#f8f7f2; color:#4a4443; width:450px; border-radius:15px; overflow:hidden; box-shadow:0 25px 50px rgba(0,0,0,0.3); border:1px solid #d6c9c7;">
            <div style="background:#917c79; padding:15px 20px; display:flex; justify-content:space-between; align-items:center;">
                <h3 style="margin:0; font-size:16px; color:#f8f7f2; font-weight:bold; letter-spacing:1px;">⚠️ 讀墨版權到期提醒</h3>
                <span id="closeX" style="cursor:pointer; font-size:20px; color:#f8f7f2; line-height:1;">✕</span>
            </div>
            
            <div style="padding:20px 20px 5px 20px; max-height:400px; overflow-y:auto; background:#f9f9f9;">
                <p style="margin:0 0 15px 0; color:#7a6e6c; font-size:13px; font-weight:bold;">偵測到您的快取中有書籍即將下架：</p>
                ${booksHtml}
            </div>
            
            <div style="padding:10px 20px 15px; text-align:center; background:#f9f9f9;">
                <button id="silentBtn" style="background:#917c79; color:#f8f7f2; border:none; padding:8px 25px; border-radius:20px; font-weight:bold; cursor:pointer; font-size:14px; box-shadow:0 4px 10px rgba(145,124,121,0.2);">不再顯示</button>
            </div>
        </div>
    `;

    document.body.appendChild(modalOverlay);

    const close = () => { 
        modalOverlay.remove(); 
        sessionStorage.setItem('hasAlertedExpiry', 'true'); 
    };
    const setSilent = () => { 
        localStorage.setItem('rm-silent-mode', 'true'); 
        close(); 
    };

    document.getElementById('closeX').onclick = close;
    document.getElementById('silentBtn').onclick = setSilent;
}

function checkCacheAndShow() {
    chrome.storage.local.get(['readmooCache'], (data) => {
        if (data.readmooCache && data.readmooCache.length > 0) {
            triggerModal(data.readmooCache);
        }
    });
}

window.addEventListener('hashchange', () => {
    sessionStorage.removeItem('hasAlertedExpiry');
    setTimeout(checkCacheAndShow, 300);
});

checkCacheAndShow();