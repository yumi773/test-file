let allSaleBooks = [];

function initSaleLogic() {
    chrome.storage.local.get(['readmoo_data'], (result) => {
        if (result.readmoo_data) {
            allSaleBooks = result.readmoo_data;
            renderSaleBooks(allSaleBooks);
        }
    });
}

document.getElementById('refreshSaleBtn').onclick = async () => {
    const btn = document.getElementById('refreshSaleBtn');
    btn.innerText = '抓取中...';
    btn.disabled = true;
    try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.id) {
            chrome.tabs.sendMessage(tab.id, { action: "DO_SCRAPE" }, () => {
                setTimeout(() => {
                    btn.innerText = '⟳ 刷新';
                    btn.disabled = false;
                }, 600);
            });
        }
    } catch (err) {
        btn.disabled = false;
    }
};

function renderSaleBooks(books, filterType = 'all') {
    const filterArea = document.getElementById('saleFilterArea');
    const app = document.getElementById('saleApp');
    if (!filterArea || !app) return;

    let filtered = books.filter(b => b.isSale);
    if (filterType === 'sale') filtered = filtered.filter(b => b.hasPriceTag);
    else if (filterType === 'activity') filtered = filtered.filter(b => b.activities.length > 0 && !b.hasPriceTag);

    // 強制 UI 更新
    filterArea.innerHTML = `
        <span>🔍 篩選結果: ${filtered.length} 本</span>
        <select id="filterSelectSale">
            <option value="all" ${filterType === 'all' ? 'selected' : ''}>所有</option>
            <option value="sale" ${filterType === 'sale' ? 'selected' : ''}>特價書</option>
            <option value="activity" ${filterType === 'activity' ? 'selected' : ''}>僅活動</option>
        </select>
    `;

    app.innerHTML = filtered.map(b => `
        <div class="book-item">
            <a href="${b.url}" target="_blank" class="book-title">
                ${b.title} 
            </a>
            <div class="price-row">
                <span class="price-val" style="color: ${b.hasPriceTag ? '#FF5252' : '#333'};">NT$ ${b.price}</span>
                ${b.hasPriceTag ? `<span class="sale-tag">特價中</span>` : ''}
            </div>
            ${b.activities.map(act => `
                <a href="${act.link}" target="_blank" class="activity-link">
                    <span>📍 ${act.text}</span>
                    <span style="float:right;">➔</span>
                </a>
            `).join('')}
        </div>`).join('');

    document.getElementById('filterSelectSale').onchange = (e) => renderSaleBooks(allSaleBooks, e.target.value);
}

chrome.storage.onChanged.addListener((changes) => {
    if (changes.readmoo_data) {
        allSaleBooks = changes.readmoo_data.newValue;
        renderSaleBooks(allSaleBooks);
    }
});