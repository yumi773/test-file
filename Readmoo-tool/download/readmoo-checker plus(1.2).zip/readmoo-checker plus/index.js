document.addEventListener('DOMContentLoaded', () => {
    const body = document.body;
    const views = {
        home: document.getElementById('homeView'),
        sale: document.getElementById('saleView'),
        expiry: document.getElementById('expiryView')
    };

    function switchView(viewName) {
        // 1. 隱藏所有視圖
        Object.values(views).forEach(v => v.classList.remove('active-view'));
        
        // 2. 切換 body 的 class 以對應各別頁面的 CSS
        body.className = `${viewName}-active`;
        
        // 3. 顯示目標視圖
        const targetView = document.getElementById(`${viewName}View`);
        if (targetView) {
            targetView.classList.add('active-view');
        }
        
        // 4. 初始化該頁面的數據 (這點沒做，彈窗就會是空的)
        if (viewName === 'sale' && typeof initSaleLogic === 'function') initSaleLogic();
        if (viewName === 'expiry' && typeof initExpiryLogic === 'function') initExpiryLogic();
    }

    // 綁定首頁卡片點擊事件
    document.getElementById('btnGoSale').onclick = () => switchView('sale');
    document.getElementById('btnGoExpiry').onclick = () => switchView('expiry');
    
    // 綁定返回按鈕
    document.querySelectorAll('.back-btn').forEach(btn => {
        btn.onclick = () => switchView('home');
    });
});