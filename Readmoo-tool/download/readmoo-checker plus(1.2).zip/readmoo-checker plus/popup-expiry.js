function initExpiryLogic() {
    renderExpiryCache();
}

async function renderExpiryCache() {
    const results = document.getElementById('expiryApp');
    const statusTime = document.getElementById('lastScanTime');
    const summary = document.getElementById('expirySummary');
    if (!results || !statusTime || !summary) return;

    const data = await chrome.storage.local.get(['readmooCache']);
    results.innerHTML = '';
    summary.innerText = '';
    
    if (data.readmooCache && data.readmooCache.length > 0) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayStr = today.toISOString().split('T')[0].replace(/-/g, '/');
        
        // 過濾：排除已到期的書 (小於今天的日期)
        const validData = data.readmooCache.filter(b => {
            if (b.expiryDate === "詳見網頁" || b.expiryDate === "未知") return true;
            const bDate = new Date(b.expiryDate);
            return bDate >= today;
        });
        
        statusTime.innerText = `最後掃描：${new Date(data.readmooCache[0].timestamp).toLocaleString()}`;
        
        if (validData.length > 0) {
            summary.innerText = `⚠️ 偵測到 ${validData.length} 本即將到期`;

            // 強化排序邏輯
            validData.sort((a, b) => {
                const dateA = (a.expiryDate === "詳見網頁" || a.expiryDate === "未知") ? "9999/12/31" : a.expiryDate;
                const dateB = (b.expiryDate === "詳見網頁" || b.expiryDate === "未知") ? "9999/12/31" : b.expiryDate;
                
                // 如果其中一個是今天，強制排最前
                if (dateA === todayStr) return -1;
                if (dateB === todayStr) return 1;
                
                return dateA.localeCompare(dateB);
            });

            validData.forEach(book => {
                const div = document.createElement('div');
                div.className = 'book-item';
                div.innerHTML = `
                    <a href="${book.url}" target="_blank" class="book-title">${book.title}</a>
                    <div class="expiry-date">⏱ 到期日: ${book.expiryDate}</div>
                `;
                results.appendChild(div);
            });
        } else { 
            summary.innerText = '目前無即將到期書籍'; 
        }
    } else {
        statusTime.innerText = '最後掃描：尚未執行';
    }
}

// 點擊事件必須在 DOMContentLoaded 時期就準備好，或確保 init 時綁定
document.getElementById('scanExpiryBtn').onclick = async () => {
    const lastScanTime = document.getElementById('lastScanTime');
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    
    if (!tab.url.includes("readmoo.com/checkout") && !tab.url.includes("readmoo.com/shopping_cart")) {
        alert("請在購物車或待購清單頁面執行"); return;
    }

    // --- 補回關鍵程式碼：按下開始掃描時，強制重置「不再顯示」狀態 ---
    await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => { 
            localStorage.removeItem('rm-silent-mode'); // 移除永久隱藏標記
            sessionStorage.removeItem('hasAlertedExpiry'); // 移除本次分頁隱藏標記
        }
    });

    const data = await chrome.storage.local.get(['readmooCache']);
    let expiryBooks = data.readmooCache || [];
    
    const injection = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => [...new Set(Array.from(document.querySelectorAll('a[href*="/book/"]')).map(a => a.href).filter(u => u.startsWith('http')))]
    });

    const urls = injection[0].result;
    for (let [i, url] of urls.entries()) {
        if (expiryBooks.some(b => b.url === url)) continue;
        lastScanTime.innerText = `掃描中: ${i+1}/${urls.length}`;
        try {
            const resp = await fetch(url);
            const text = await resp.text();
            if (text.includes("版權即將到期")) {
                const title = text.match(/<h1[^>]*>([\s\S]*?)<\/h1>/)?.[1]?.trim().replace(/<[^>]+>/g, '') || "未知書籍";
                const expiry = text.match(/版權即將到期：\s*(\d{4}\/\d{2}\/\d{2})/)?.[1] || "詳見網頁";
                expiryBooks.push({ title, url, expiryDate: expiry, timestamp: Date.now() });
                await chrome.storage.local.set({ readmooCache: expiryBooks });
            }
        } catch (e) {}
    }
    renderExpiryCache();
};

document.getElementById('clearExpiryBtn').onclick = async () => {
    await chrome.storage.local.remove('readmooCache');
    renderExpiryCache();
};