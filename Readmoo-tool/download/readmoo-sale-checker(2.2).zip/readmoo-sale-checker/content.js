function scrapeReadmoo() {
  if (!chrome.runtime?.id) return;
  
  const books = [];
  const items = document.querySelectorAll('.cart-list-item, .cart-item, .cart-wishlist-item');

  items.forEach(item => {
    const bookLinkEl = item.querySelector('a[href*="/book/"]');
    const bookUrl = bookLinkEl ? bookLinkEl.href : "";
    
    const checkbox = item.querySelector('input[type="checkbox"][aria-label*="選取商品"]');
    let title = checkbox ? checkbox.getAttribute('aria-label').replace('選取商品：', '').trim() : "";
    if (!title && bookLinkEl) title = bookLinkEl.innerText.trim();
    
    if (title && title.length > 1) {
        const itemText = item.innerText || "";
        const ntMatch = itemText.match(/NT\$\s*([\d,]+)/);
        let price = ntMatch ? parseInt(ntMatch[1].replace(/,/g, ''), 10) : 0;
        
        // --- 核心修正：偵測你發現的精準特價標籤 ---
        const priceTag = item.querySelector('span.mb-sm-2.badge.bg-notice');
        
        const activityData = [];
        const links = item.querySelectorAll('a');
        links.forEach(anchor => {
            const text = anchor.innerText.trim();
            const href = anchor.href;
            if ((text.includes('折') || text.includes('展') || text.includes('前，') || text.includes('適用優惠')) && 
                !href.includes('/book/') && text.length > 2) {
                const cleanText = text.replace('適用優惠：', '').trim();
                if (!activityData.some(a => a.text === cleanText)) {
                    activityData.push({ text: cleanText, link: href });
                }
            }
        });

        // 只要有活動連結或有特價標籤，就視為 Sale 書籍
        const isSale = activityData.length > 0 || !!priceTag || itemText.includes('特價');

        if (price > 0) {
            books.push({ 
              title, 
              price, 
              isSale, 
              url: bookUrl,
              activities: activityData,
              hasPriceTag: !!priceTag // 記錄是否偵測到那個紅色 [特價] 標籤
            });
        }
    }
  });

  const uniqueBooks = Array.from(new Map(books.map(b => [b.title, b])).values());
  chrome.storage.local.set({ 'readmoo_data': uniqueBooks });
    console.log(`✅ 手動刷新完成，共 ${uniqueBooks.length} 本，含活動連結：${uniqueBooks.filter(b=>b.activities.length>0).length} 本`);
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "DO_SCRAPE") {
    scrapeReadmoo();
    sendResponse({ result: "success" });
  }
  return true; 
});