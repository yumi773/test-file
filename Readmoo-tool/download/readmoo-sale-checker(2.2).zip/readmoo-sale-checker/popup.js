let allFetchedBooks = []; // 存放原始資料

document.addEventListener('DOMContentLoaded', () => {
  const refreshBtn = document.getElementById('refreshBtn');

  // 初始化載入
  chrome.storage.local.get(['readmoo_data'], (result) => {
    if (result.readmoo_data) {
      allFetchedBooks = result.readmoo_data;
      renderBooks(allFetchedBooks);
    }
  });

  refreshBtn.addEventListener('click', async () => {
    refreshBtn.innerText = '抓取中...';
    refreshBtn.disabled = true;
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id) {
        chrome.tabs.sendMessage(tab.id, { action: "DO_SCRAPE" }, () => {
          setTimeout(() => {
            refreshBtn.innerText = '⟳ 刷新資料';
            refreshBtn.disabled = false;
          }, 600);
        });
      }
    } catch (err) {
      alert("請確保您在讀墨網頁上！");
      refreshBtn.disabled = false;
    }
  });

  // 監聽資料變動
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.readmoo_data) {
      allFetchedBooks = changes.readmoo_data.newValue;
      renderBooks(allFetchedBooks);
    }
  });
});

function renderBooks(books, filterType = 'all') {
  const app = document.getElementById('app');
  
  // 1. 二次篩選邏輯：精確拆分
  let filtered = books.filter(b => b.isSale); // 基礎集
  
  if (filterType === 'sale') {
    // 僅看特價：必須有紅標籤
    filtered = filtered.filter(b => b.hasPriceTag);
  } else if (filterType === 'activity') {
    // 僅看活動：必須有活動連結，且「排除」掉有紅標籤的書
    filtered = filtered.filter(b => b.activities.length > 0 && !b.hasPriceTag);
  }

  if (books.length === 0) {
    app.innerHTML = '<div style="padding:20px; color:#999; text-align:center;">目前清單內無活動書籍。</div>';
    return;
  }

  // 2. 構建凍結標題與下拉選單 (稍微修改選單文字，讓功能更明確)
  const headerHtml = `
    <div class="sticky-header">
      <span>🔍 篩選後共 ${filtered.length} 本：</span>
      <select id="filterSelect">
        <option value="all" ${filterType === 'all' ? 'selected' : ''}>所有</option>
        <option value="sale" ${filterType === 'sale' ? 'selected' : ''}>特價書</option>
        <option value="activity" ${filterType === 'activity' ? 'selected' : ''}>僅活動</option>
      </select>
    </div>
  `;

  // 3. 構建列表
  const listHtml = filtered.map(b => `
    <div class="book-item">
      <div style="margin-bottom: 5px;">
        <a href="${b.url}" target="_blank" style="text-decoration: none; color: #333; font-weight: bold; font-size: 14px;">
          ${b.title} 
        </a>
      </div>
      <div class="price-row">
        <span style="color: ${b.hasPriceTag ? '#FF5252' : '#333'};">NT$ ${b.price}</span>
        ${b.hasPriceTag ? `<span style="background: #7e7676; color: white; font-size: 10px; padding: 2px 6px; border-radius: 10px; margin-left: 8px; vertical-align: middle;">
          🔥 特價中</span>` : ''}
      </div>
      ${b.activities.map(act => `
        <a href="${act.link}" target="_blank" class="activity-link">📍 ${act.text} <span style="float:right;">➜</span></a>
      `).join('')}
    </div>
  `).join('');

  app.innerHTML = headerHtml + listHtml;

  // 4. 為新生成的下拉選單綁定事件
  document.getElementById('filterSelect').addEventListener('change', (e) => {
    renderBooks(allFetchedBooks, e.target.value);
  });
}